dotnet new --uninstall Graic.Template.GorillaTagModTemplate.nuspec
dotnet new --install (ls *.nupkg -Recurse)