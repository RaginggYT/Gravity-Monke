﻿namespace GorillaTagModTemplateProject
{
	/// <summary>
	/// This class is used to provide information about your mod to BepInEx.
	/// </summary>
	class PluginInfo
	{
		public const string GUID = "com.ragingg.gorillatag.gravitymonke";
		public const string Name = "Gravity Monke";
		public const string Version = "1.0.0";
	}
}
